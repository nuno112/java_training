var toppings = {};
var elements;
var toppingCount = 0;
var warnings = [];

function getToppings () {
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].checked === true) {
            toppings[elements[i].id] = elements[i].value;
        } else {
            toppings[elements[i].id] = "off";
        }
    }
}

function maxTopping () {
    toppingCount = 0;
    warnings[0] = "";
    document.getElementById("warnings").innerHTML = "";
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].checked === true) {
            toppingCount++;
        }
    }
    console.log("toppingCOunt: " + toppingCount);
    if (toppingCount > 3) {
        warnings[0] = "Select only at most 3 toppings please!";
        document.getElementById("warnings").textContent = warnings[0];
        console.log(document.getElementById("warnings").textContent);
        return false;
    } else {
        return true;
    }
}

function messy() {
    warnings[1] = "";
    document.getElementById("warnings").textContent = "";
    if (document.getElementById("strawberry_syrup").checked === true 
        && document.getElementById("caramel_sauce").checked === true) {
        warnings[1] = "Do not select both Strawberry syrup and Caramel sauce please!";
        document.getElementById("warnings").textContent = warnings[0] + " " + warnings[1];
        return false;
    } else {
        return true;
    }
}

function sendData () {
    var empty = false;
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].checked === true) {
            empty = true;
        }
    }
    if (empty) {
        if (maxTopping()) {
            if (messy()) {
                alert("Toppings chosen! Thank you for your preference!");
                clear();
                //submit data to server through the object toppings
            } else {
                alert("Do not select both Strawberry syrup and Caramel sauce please!");
                clear();
                //do not submit data to server
            }
        } else {
            alert("Select only at most 3 toppings please!");
            clear();
            //do not submit data to server
        }
    } else {
        alert("Select at least 1 topping please!");
        //do not submit data to server
    }
}

function clear() {
    for (var i = 0; i < elements.length; i++) {
        elements[i].checked = false;  
    }
    document.getElementById("warnings").innerHTML = "";
}

function init() {
    elements = document.querySelectorAll("#form input[type=checkbox]");
    getToppings();
    return false;
}

window.onload = function() {
    init();
}