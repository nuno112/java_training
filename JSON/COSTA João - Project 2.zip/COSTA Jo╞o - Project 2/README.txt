Please open the login.html file first and then create an account.
Then login with the created account and start the predictions.