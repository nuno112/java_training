package costa.joao.utilities;

import org.json.simple.*;
import org.json.simple.parser.*;

import costa.joao.assets.*;
import costa.joao.company.Company;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Iterator;

import static java.lang.Math.toIntExact;

public class JsonRead {
	@SuppressWarnings("unchecked")
	public static void read(String path) {

        JSONParser parser = new JSONParser();

        try {

        	Company.getCompanyActivities().clear();
            Company.getCompanyTeams().clear();
            Company.getCompanyProgrammers().clear();
        	
            Object obj = parser.parse(new FileReader(path));
            JSONObject jsonObject = (JSONObject) obj;
            
            //Parse activities
            JSONArray activities = (JSONArray) jsonObject.get("activities");
            Iterator<JSONObject> iterator1 = activities.iterator();            
            
            while (iterator1.hasNext()) {
                
            	JSONObject activity = (JSONObject) iterator1.next();
                String description = (String) activity.get("description");
                String endDate = (String) activity.get("endDate");
                String startDate = (String) activity.get("startDate");
                int id = toIntExact((long) activity.get("id"));
                
                Activity activity_ = new Activity(description, LocalDate.parse(startDate), LocalDate.parse(endDate));
                activity_.setId(id);
                
                Company.getCompanyActivities().add(activity_);
            }
            
            //Parse programmers
            JSONArray programmers = (JSONArray) jsonObject.get("programmers");
            Iterator<JSONObject> iterator2 = programmers.iterator();
            while (iterator2.hasNext()) {
                
            	JSONObject programmer = (JSONObject) iterator2.next();
                String firstName = (String) programmer.get("firstName");
                String lastName = (String) programmer.get("lastName");
                int activityId = toIntExact((long) programmer.get("activityId"));
                int id = toIntExact((long) programmer.get("id"));
                
                Programmer programmer_ = new Programmer(lastName, firstName, activityId);
                programmer_.setId(id);
                
                Company.getCompanyProgrammers().add(programmer_);
            }
            
            //Parse ProjectTeams
            JSONArray projectTeams = (JSONArray) jsonObject.get("projectTeams");
            Iterator<JSONObject> iterator3 = projectTeams.iterator();
            while (iterator3.hasNext()) {
                
            	JSONObject team = (JSONObject) iterator3.next();
            	
            	int salaryRatio = toIntExact((long) team.get("salaryRatio"));
            	int id = toIntExact((long) team.get("id"));
            	
            	ProjectTeam team_ = new ProjectTeam(salaryRatio);
            	team_.setId(id);
            	
            	JSONArray programmerList = (JSONArray) team.get("programmerList");
            	Iterator<JSONObject> iterator4 = programmerList.iterator();
            	
            	while (iterator4.hasNext()) {
            		
            		JSONObject programmerObj = (JSONObject) iterator4.next();
                	
                	int programmerId = toIntExact((long) programmerObj.get("programmerID"));
            		team_.addProgrammer(Company.getCompanyProgrammers().get(programmerId -1));
            	}
            	Company.getCompanyTeams().add(team_);
            }
            
        } catch (FileNotFoundException e) {
        	System.out.println("File not found.\n Initializing data...");
        	Company.initialize();
        	JsonWrite.write(path);
        	System.out.println("Data initialized. File created:  " + path);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }
}
