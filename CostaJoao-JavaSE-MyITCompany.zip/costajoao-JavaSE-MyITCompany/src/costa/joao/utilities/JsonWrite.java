package costa.joao.utilities;

import org.json.simple.*;

import java.io.FileWriter;
import java.io.IOException;

import costa.joao.assets.*;
import costa.joao.company.*;

public class JsonWrite {
	
	@SuppressWarnings("unchecked")
	public static void write(String path) {
        JSONArray projectTeams = new JSONArray();
        JSONArray programmers = new JSONArray();
        JSONArray activities = new JSONArray();
        
        for(ProjectTeam team: Company.getCompanyTeams()) {        	
        	projectTeams.add(team);
			for(Programmer programmer: team.getProgrammerList()) {
				programmers.add(programmer);
			}
        }
        
        for(Activity activity: Company.getCompanyActivities()){
        	activities.add(activity);
        }        
        
        if (projectTeams.isEmpty()) {
        	System.out.println("There is no loaded data to save.");
        	return;
        }
        
        try (FileWriter file = new FileWriter(path)) {
        	file.write("{ \"projectTeams\": ");
            file.write(projectTeams.toJSONString());
            file.write(", \"programmers\": ");
            file.write(programmers.toJSONString());
            file.write(", \"activities\": ");
            file.write(activities.toJSONString());
            file.write("}");
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
