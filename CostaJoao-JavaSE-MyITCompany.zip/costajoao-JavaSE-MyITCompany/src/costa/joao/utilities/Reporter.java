package costa.joao.utilities;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Iterator;

import costa.joao.assets.*;
import costa.joao.company.*;

import static java.lang.Math.toIntExact;

public class Reporter {
	
	private static StringBuilder report = new StringBuilder();

	public static StringBuilder getReport() {
		return report;
	}

	public static int[] calcDays() {
		
		Iterator<Programmer> programmerIterator = Company.getCompanyProgrammers().iterator();
		
		int[] x = new int[3];
		
		/*
		 *  daysConsumed = x[0];
		 *  programmersInCharge = x[1];
		 *  daysInCharge = x[2];
		 */
		
		while(programmerIterator.hasNext()){
			Programmer programmer = programmerIterator.next();
			
			if(LocalDate.now().isAfter(programmer.getActivity().getStartDate())){
			
				x[2] += toIntExact(ChronoUnit.DAYS.between(LocalDate.now(), programmer.getActivity().getEndDate()));
				
				if(LocalDate.now().isAfter(programmer.getActivity().getEndDate())
						&& programmer.getActivity().getEndDate().getMonth() == LocalDate.now().getMonth()) {
					x[0] += programmer.getActivity().getEndDate().getDayOfMonth();
					x[1]++;
				} else if (LocalDate.now().isBefore(programmer.getActivity().getEndDate())){
					x[0] += LocalDate.now().getDayOfMonth();
					x[1]++;
				}
			}	
		}		
		return x;
	}
	
	public static void generateReport() {
		if(Company.getCompanyProgrammers().isEmpty()){
			System.out.println("Please load the data first.");
			return;
		}
		
		int[] a = calcDays();
		
		int daysConsumed = a[0];
		int programmersInCharge = a[1];
		int daysInCharge = a[2];
		
		report.append("\n\nIT COMPANY  - Report\n\n");
		
		report.append("IT Company is actually composed of " + Company.getCompanyTeams().size()
				+ " project teams, and " + Company.getCompanyProgrammers().size() + " programmers.\n");
		
		report.append("This month, " + daysConsumed + " days (sum of days worked by each programmer) have been consumed by " + programmersInCharge
				+ " programmers, and " + daysInCharge + " days (sum of work days remaining by each programmer) still in charge.\n\n");
		
		report.append("Project teams details.\n");

		Iterator<ProjectTeam> teamsIterator = Company.getCompanyTeams().iterator();
		
		while(teamsIterator.hasNext()){
			ProjectTeam team = teamsIterator.next();
			
			report.append("\nProject Team n�: " + team.getId() + "\n\n");		
			
			Iterator<Programmer> programmerIterator = Company.getCompanyProgrammers().iterator();
			
			while(programmerIterator.hasNext()){
				Programmer programmer = programmerIterator.next();
				
				if(programmer.getAssignedTeam() == team.getId()) {
					report.append(programmer.toReport());
				}
			}
		}
	}
}
