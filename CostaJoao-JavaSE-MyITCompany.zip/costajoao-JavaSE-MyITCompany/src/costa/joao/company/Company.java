/*
 * Made by Jo�o Nuno Miranda Costa 2018
 * 
 */

package costa.joao.company;

import costa.joao.assets.*;
import costa.joao.utilities.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;

public class Company {
	
	private static ArrayList<ProjectTeam> companyTeams = new ArrayList<>();
	private static ArrayList<Activity> companyActivities = new ArrayList<>();
	private static ArrayList<Programmer> companyProgrammers = new ArrayList<>();
	
	public static void update() {
		if(!companyProgrammers.isEmpty()) {
			for(ProjectTeam team: companyTeams) {
				for(Programmer programmer: team.getProgrammerList()) {
					LocalDate previousDate = programmer.getActivity().getEndDate();
					programmer.getActivity().setEndDate(previousDate.plus(1, ChronoUnit.DAYS));
				}
			}
		} else {
			System.out.println("There is no loaded data to update.");
		}
	}
	
	public static ArrayList<ProjectTeam> getCompanyTeams() {
		return companyTeams;
	}
	
	public static ArrayList<Activity> getCompanyActivities() {
		return companyActivities;
	}

	public static ArrayList<Programmer> getCompanyProgrammers() {
		return companyProgrammers;
	}
	
	public static void initialize() {
		
		Activity frontEnd = new Activity("Create Front End with AngularJS", LocalDate.of(2018, 1, 1), LocalDate.of(2018, 6, 3));
		companyActivities.add(frontEnd);
		Activity backEnd = new Activity("Create Back End with JAVA", LocalDate.of(2018, 2, 1), LocalDate.of(2018, 7, 1));
		companyActivities.add(backEnd);
		Activity design = new Activity("Design the Front End", LocalDate.of(2018, 1, 1), LocalDate.of(2018, 6, 1));
		companyActivities.add(design);
		Activity quality = new Activity("Ensure the Project Quality", LocalDate.of(2018, 2, 1), LocalDate.of(2018, 10, 1));
		companyActivities.add(quality);
		
		Programmer p1 = new Programmer("Costa", "Joao", frontEnd);
		companyProgrammers.add(p1);
		Programmer p2 = new Programmer("Barreiros", "Quim", backEnd);
		companyProgrammers.add(p2);
		Programmer p3 = new Programmer("Paulo", "Marco", design);
		companyProgrammers.add(p3);
		Programmer p4 = new Programmer("Carreira", "Tony", quality);
		companyProgrammers.add(p4);
			
		ProjectTeam team1 = new ProjectTeam(50, p1, p2);
		companyTeams.add(team1);
		ProjectTeam team2 = new ProjectTeam(100,p3,p4);
		companyTeams.add(team2);
	}

	public static void main(String[] args) {
		
		String path = ".\\MyITCompanyData\\data.json";
		
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter 1 to load file\nEnter 2 to save data\nEnter 3 to update data\nEnter 4 to generate report\nEnter 5 to exit");
		while(reader.hasNext()){
			
			int n = reader.nextInt();
			
			switch (n) {
				case 1: JsonRead.read(path);
						break;
				case 2: JsonWrite.write(path);
						break;
				case 3: Company.update();
						break;
				case 4: Reporter.generateReport();
						System.out.println(Reporter.getReport());
						break;
				case 5: return;
			}
			System.out.println("Enter 1 to load file\nEnter 2 to save data\nEnter 3 to update data\nEnter 4 to generate report\nEnter 5 to exit");
		}
		reader.close();
	}
}
