package costa.joao.assets;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Activity {
	private String description;
	private LocalDate startDate;
	private LocalDate endDate;
	private int id;

	private static int activityCounter;
	
	public static int getActivityCounter() {
		return activityCounter;
	}

	public static void setActivityCounter(int activityCounter) {
		Activity.activityCounter = activityCounter;
	}
	
	public Activity(String description, LocalDate startDate, LocalDate endDate){
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		activityCounter++;
		this.id = activityCounter;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getDescription(){
		return description;
	}
	
	public void setDescription(String description){
		this.description = description;
	}
	
	public LocalDate getStartDate() {
		return startDate;
	}
	
	public LocalDate getEndDate() {
		return endDate;
	}
	
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	
	public long calcDuration() {
		return ChronoUnit.DAYS.between(startDate, endDate);
	}
	
	public String toString() {
		String s =  "{\"description\": \"" + description + "\" ,\"startDate\": \""+ startDate
				+ "\" ,\"endDate\": \""+ endDate
				+ "\", \"id\": " + getId() + "}";
		return s;
	}
}
