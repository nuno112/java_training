package costa.joao.assets;

public interface Employee {
		
	public String getLastName();
	public String getFirstName();

	public Activity getActivity();
	
	public double getSalary();
	public void setSalary();
	
	public int getId();
	
	public int getEmployeeCounter();
	
}