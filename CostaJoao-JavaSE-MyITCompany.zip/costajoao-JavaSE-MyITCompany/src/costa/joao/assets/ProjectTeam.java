package costa.joao.assets;

import java.util.ArrayList;

public class ProjectTeam {
	private int salaryRatio;
	private int id;
	private static int teamCounter;
	private ArrayList<Programmer> programmerList = new ArrayList<>();
	
	public ArrayList<Programmer> getProgrammerList() {
		return programmerList;
	}

	public ProjectTeam(int salaryRatio, Programmer... varArgs) {
		this.salaryRatio = salaryRatio;
		for(Programmer programmer:varArgs){
			this.addProgrammer(programmer);
		}
		teamCounter++;
		this.id = teamCounter;
	}
	
	public void addProgrammer(Programmer programmer) {
		programmerList.add(programmer);
		programmer.setAssignedTeam(this);
	}
	
	public static int getTeamCounter() {
		return teamCounter;
	}
	
	public static void setTeamCounter(int teamCounter) {
		ProjectTeam.teamCounter = teamCounter;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSalaryRatio() {
		return salaryRatio;
	}
	
	public String toString() {
		
		String s = "{\"salaryRatio\": " + salaryRatio + " ,\"programmerList\":"
				+" [{\"programmerID\": " + programmerList.get(0).getId() + "}, {\"programmerID\": " + programmerList.get(1).getId()
				+"}], \"id\": " + getId() + "}";
		return s;
	}
}
