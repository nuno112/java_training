package costa.joao.assets;

import java.text.NumberFormat;
import java.time.LocalDate;
import costa.joao.company.Company;

public class Programmer implements Employee {
	
	private static final double SALARY = 1000;
	
	private static int employeeCounter;
	
	private String lastName;
	private String firstName;
	private ProjectTeam assignedTeam;
	private Activity activity;
	private double salary;
	private int id;

	public Programmer(String lastName, String firstName, Activity activity){
		this.lastName = lastName;
		this.firstName = firstName;
		this.activity = activity;
		employeeCounter++;
		this.id = employeeCounter;
	}
	
	public Programmer(String lastName, String firstName, int activityId){
		this.lastName = lastName;
		this.firstName = firstName;
		this.activity = Company.getCompanyActivities().get(activityId - 1);
		employeeCounter++;
		this.id = employeeCounter;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public int getAssignedTeam() {
		return assignedTeam.getId();
	}
	
	public void setAssignedTeam(ProjectTeam assignedTeam) {
		this.assignedTeam = assignedTeam;
		this.setSalary();
	}
	
	public Activity getActivity() {
		return activity;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public void setSalary() {
		salary = assignedTeam.getSalaryRatio()  * SALARY / 100;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeCounter() {
		return employeeCounter;
	}
	
	public String getTotalCost() {
		NumberFormat formatter = NumberFormat.getCurrencyInstance();
		return formatter.format(salary * activity.calcDuration() / 30);
	}
	
	public int daysThisMonth() {
		int x = 0;
		
		if(LocalDate.now().isAfter(getActivity().getStartDate())){
			
			if(LocalDate.now().isAfter(getActivity().getEndDate())
					&& getActivity().getEndDate().getMonth() == LocalDate.now().getMonth()) {
				x = getActivity().getEndDate().getDayOfMonth();

			} else if (LocalDate.now().isBefore(getActivity().getEndDate())){
				x = LocalDate.now().getDayOfMonth();
			}
		}
		return x;
	}

	public String toString(){
		String s;
		if(assignedTeam != null) {
			s = "{\"firstName\": \"" + firstName + "\" ,\"lastName\": \"" + lastName 
					+ "\" ,\"assignedTeamId\": " + assignedTeam.getId()
					+ " ,\"activityId\": " + activity.getId()
					+ " ,\"salary\": " + salary + " ,\"id\": " + getId() + "}";

		} else {
			s = "{\"firstName\": \"" + firstName + "\" ,\"lastName\": \"" + lastName 
					+ "\" ,\"assignedTeamId\": \"unassigned\""
					+ " ,\"activityId\": " + activity.getId()
					+ " ,\"salary\": " + salary + " ,\"id\": " + getId() + "}";
		}
		return s;
	}
	
	public String toReport(){
		String s = lastName + ", " + firstName + " in charge of " + activity.getDescription() +
				" from " + activity.getStartDate() + " to " + activity.getEndDate() +
				" (duration " + activity.calcDuration() + " days), this month : " + daysThisMonth() +
				" days (total monthly cost = " + getTotalCost() + ")\n";
		return s;
	}
}
